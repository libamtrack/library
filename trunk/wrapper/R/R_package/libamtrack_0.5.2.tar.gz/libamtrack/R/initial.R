.onLoad <- function(lib, pkg){
 library.dynam("libamtrack", pkg, lib)
 packageStartupMessage("This is libamtrack 0.5.2 'Red Wombat' (Development, 1135:1136M, 2011-12-13 11:44:47).\nType '?libamtrack' for help.\n")
}
.Last.lib <- function(libpath){
 try(library.dynam.unload("libamtrack", libpath))
}
